package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;
import exam.model.examModel;

@WebServlet("/addExam")
public class addExam extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		Boolean flag=false;
		Boolean flag1=true;
		Boolean flag2=false;
		LocalDate start_date=null;
		LocalDate end_date=null;
		String exam1=null;
		String exam2=null;
		String exam=(String) request.getParameter("examdate");
		LocalDate exam_date=LocalDate.parse(exam);
		HttpSession adminsess2=request.getSession();
		PrintWriter out=response.getWriter();
		int exam_id=Integer.valueOf((String) request.getParameter("exam_id"));
		String sub_name=(String) request.getParameter("sub_name");
		int clss_no=Integer.valueOf((String) request.getParameter("clss_no"));
		int no_of_que=Integer.valueOf((String) request.getParameter("no_of_ques"));
		String time_interval=(String) request.getParameter("time_interval");
		int total_marks=Integer.valueOf((String) request.getParameter("total_marks"));;
		if(adminsess2.getAttribute("enddate")!=null){
			exam1=(String) adminsess2.getAttribute("startdate");
			exam2=(String) adminsess2.getAttribute("enddate");
		 start_date=LocalDate.parse(exam1);
		 end_date=LocalDate.parse(exam2);
		}else{
			start_date=LocalDate.parse(exam);
			end_date=start_date.plusDays(4);
			exam1=start_date.toString();
			exam2=end_date.toString();
		}
		HttpSession adminsess1=request.getSession();
		int clssno1=Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		ArrayList<String> examsub= new ArrayList<String>();
		examsub=selectExam.getExamSubject(clssno1);
	
		for(String r: examsub)
		{
			if(r.equals(sub_name))
			{
				flag2=true;
				break;
			}
		}
		examModel e=new examModel(exam_id, sub_name, clss_no, no_of_que,time_interval,total_marks, exam1 ,exam2, exam);
				if(exam_date.equals(end_date))
				{
						if(selectExam.addExam(e) ==true)
						{
							rd=request.getRequestDispatcher("examList");
							rd.forward(request, response);
						}else{
							out.println("<script type=\"text/javascript\">");
							out.println("alert('Couldn't insert!!, check credentials');");
							out.println("location='addExamAdmin.jsp';");
							out.println("</script>");
						}
				} else {
		
						if(selectExam.addExam(e) ==true)
						{
							adminsess2.removeAttribute("examdate1");
							adminsess2.setAttribute("examdate1", e.getExam_date());
							rd=request.getRequestDispatcher("addExamAdmin");
							rd.forward(request, response);
						}else{
							out.println("<script type=\"text/javascript\">");
							out.println("alert('Couldn't insert!!, check credentials');");
							out.println("location='addExamAdmin.jsp';");
							out.println("</script>");
						}
				}
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
