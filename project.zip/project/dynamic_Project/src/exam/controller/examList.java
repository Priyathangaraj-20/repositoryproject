package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;
import exam.model.examModel;

@WebServlet("/examList")
public class examList extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		PrintWriter out= response.getWriter();
		HttpSession adminsess1=request.getSession();
		ArrayList<examModel> exams= new ArrayList<examModel>();
		int clss_no= Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		String startdate=null;
		String enddate=null;
		int n=selectExam.getSubNo(clss_no);
		System.out.println(n);
		HttpSession adminsess2=request.getSession();
		adminsess2.removeAttribute("startdate");
		adminsess2.removeAttribute("enddate");
		ArrayList<examModel> examinter= new ArrayList<examModel>();
		examinter=selectExam.getExamInterval(clss_no);
		for(examModel r:examinter)
		{
			startdate=r.getStart_date();
			enddate=r.getEnd_date();
			if(n==5){
			adminsess2.setAttribute("n", n);
			}else{
				adminsess2.setAttribute("n", "null");
			}
			adminsess2.setAttribute("startdate", startdate);
			adminsess2.setAttribute("enddate", enddate);
			break;
		}
		if(selectExam.getExamByClass(clss_no)!=null)
		{
			
			exams=selectExam.getExamByClass(clss_no);
			request.setAttribute("exams", exams);
			rd=request.getRequestDispatcher("examListAdmin.jsp");
			rd.forward(request, response);
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
