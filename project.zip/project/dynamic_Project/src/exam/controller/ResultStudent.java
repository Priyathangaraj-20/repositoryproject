package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectQuestions;
import exam.DAO.selectResultStudentDAO;
import exam.model.questionModel;
import exam.model.studentResultModel;

@WebServlet("/ResultStudent")
public class ResultStudent extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		HttpSession adminsess1= request.getSession();
		ArrayList<studentResultModel> subname=new ArrayList<studentResultModel>();
		ArrayList<studentResultModel> results=new ArrayList<studentResultModel>();
		int clss_no= Integer.parseInt((String) adminsess1.getAttribute("clss_no"));
		String sub_name=request.getParameter("select");
		String totalmarks= Integer.toString(selectResultStudentDAO.getMarks(clss_no, sub_name));
		System.out.print(sub_name);
		 if(selectResultStudentDAO.getResults(clss_no, sub_name)!=null){
			results=selectResultStudentDAO.getResults(clss_no, sub_name);
			request.setAttribute("totalmarks", totalmarks);
			request.setAttribute("results", results);
			System.out.print(sub_name);
			HttpSession adminsess2 = request.getSession();
			adminsess2.setAttribute("sub_name", sub_name);
			subname=(ArrayList<studentResultModel>) selectResultStudentDAO.getSub(clss_no);
			request.setAttribute("subname", subname);
			rd=request.getRequestDispatcher("studentResultAdmin.jsp");
			rd.forward(request, response);
		} else if(sub_name.equals("SELECT")){
			subname=(ArrayList<studentResultModel>) selectResultStudentDAO.getSub(clss_no);
			request.setAttribute("subname", subname);
			rd=request.getRequestDispatcher("studentResultAdmin.jsp");
			rd.forward(request, response);	
		} 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
