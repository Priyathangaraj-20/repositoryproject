package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.editProfileDAO;
import exam.DAO.indexDAO;
import exam.model.registrationmodel;


@WebServlet("/editProfile")
public class editProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		HttpSession session1=request.getSession();
		ArrayList<registrationmodel> student1;
		String email_id=(String) session1.getAttribute("email_id");
		if(editProfileDAO.getStudentDetail(email_id)!=null)
		{
			student1=editProfileDAO.getStudentDetail(email_id);	
			request.setAttribute("student1", student1);
			
			rd=request.getRequestDispatcher("editProfile.jsp");
			rd.forward(request, response);
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
