package exam.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;
import exam.DAO.selectQuestions;
import exam.model.examModel;
import exam.model.questionModel;

@WebServlet("/addExamAdmin")
public class addExamAdmin extends HttpServlet {
	
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		String startdate=null;
		String enddate=null;
		
		HttpSession adminsess1=request.getSession();
		adminsess1.removeAttribute("examid");
		HttpSession adminsess2=request.getSession();
		HttpSession adminsess3=request.getSession();		
		int clssno1=Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		if(selectExam.getExamDate1(clssno1)!=null){
		LocalDate todayDate = selectExam.getExamDate1(clssno1);   
        adminsess3.setAttribute("examdate", todayDate.plusDays(1));
		}else{
			request.setAttribute("msg", "Please enter the date when exam should start");
		}
		ArrayList<String> subject=new ArrayList<String>();
		ArrayList<String> subjectunique=new ArrayList<String>();
		subject=selectExam.getExamSubject(clssno1);
		ArrayList<String> name=new ArrayList<String>(Arrays.asList("ENGLISH","HINDI","MATHS","SCIENCE","SOCIAL"));
		name.removeAll(subject);
		ArrayList<examModel> examinter= new ArrayList<examModel>();
		examinter=selectExam.getExamInterval(clssno1);
		for(examModel r:examinter)
		{
			startdate=r.getStart_date();
			enddate=r.getEnd_date();
			adminsess2.setAttribute("startdate", startdate);
			adminsess2.setAttribute("enddate", enddate);
			break;
		}
		ArrayList<Integer> quest= new ArrayList<Integer>();
		quest=selectExam.getExamId();
		int n=1;
		int examid=0;
		for(Integer r: quest)
		{
			if(r == n)
			{
				n++;
			}
			else 
			{
				examid=n;
				adminsess1.setAttribute("examid", n);
				break;
			}
		}
		request.setAttribute("subjectunique", name);
		rd=request.getRequestDispatcher("addExamAdmin.jsp");
		rd.forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
