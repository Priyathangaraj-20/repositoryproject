package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;

import exam.model.examModel;
import exam.model.questionModel;

@WebServlet("/EditExams")
public class EditExams extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			RequestDispatcher rd;
			
			ArrayList<examModel> editexam= new ArrayList<examModel>();
			String oper="";
			int exam_id=0;
			if(request.getParameter("oper")!=null )
			{
				oper=request.getParameter("oper");
				exam_id=Integer.valueOf(request.getParameter("exam_id"));
				if(oper.equals("modify"))
				{
					editexam = selectExam.getExamById(exam_id);
					request.setAttribute("exam", editexam);
					rd=request.getRequestDispatcher("editExam.jsp");		    
			 	    rd.forward(request, response);
				}
				else if(oper.equals("delete"))
				{
					if(selectExam.deleteExamById(exam_id)==true)
					{
						rd=request.getRequestDispatcher("examList");		    
				 	    rd.forward(request, response);
					}
				}
			}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
