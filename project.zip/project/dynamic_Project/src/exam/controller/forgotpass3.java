package exam.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.forgotpassDAO;


@WebServlet("/forgotpass3")
public class forgotpass3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("submit").equals("Change"))
		{
			RequestDispatcher rd;
			String pass=request.getParameter("pass");
			String pass1=request.getParameter("pass1");
			HttpSession session=request.getSession();
			String email_id=(String) session.getAttribute("email_id");
			if(pass.equals(pass1))
			{
				if(forgotpassDAO.forgotpass3(email_id, pass)==true){
				request.setAttribute("errormsg", "Password changed succesfully, please login");
				rd=request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
				}
			}
			else
			{
				request.setAttribute("errormsg", "Password mismatch, Reenter correct password.");
				session.removeAttribute(email_id);
				rd=request.getRequestDispatcher("forgotpass3.jsp");
				rd.forward(request, response);
			}
		}	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
