package exam.model;

public class studentResultModel {
	int clss_no;
	String email_id;
	String name;
	String app_date;
	int app_id;
	int obt_marks;
	String status;
	String remarks;
	String sub_name;
	int exam_id;
	public int getExam_id() {
		return exam_id;
	}
	public void setExam_id(int exam_id) {
		this.exam_id = exam_id;
	}
	public studentResultModel(int clss_no, String email_id, String name, String app_date, int app_id, int obt_marks, String status,
			String remarks, String sub_name, int exam_id) {
		super();
		this.clss_no=clss_no;
		this.email_id = email_id;
		this.name = name;
		this.app_date = app_date;
		this.app_id = app_id;
		this.obt_marks = obt_marks;
		this.status = status;
		this.remarks = remarks;
		this.sub_name = sub_name;
		this.exam_id=exam_id;
	}
	public int getClss_no() {
		return clss_no;
	}
	public void setClss_no(int clss_no) {
		this.clss_no = clss_no;
	}
	public studentResultModel(String sub_name) {
		super();
		this.sub_name = sub_name;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getApp_date() {
		return app_date;
	}
	public void setApp_date(String app_date) {
		this.app_date = app_date;
	}
	public int getApp_id() {
		return app_id;
	}
	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}
	public int getObt_marks() {
		return obt_marks;
	}
	public void setObt_marks(int obt_marks) {
		this.obt_marks = obt_marks;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getSub_name() {
		return sub_name;
	}
	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	} 
}
