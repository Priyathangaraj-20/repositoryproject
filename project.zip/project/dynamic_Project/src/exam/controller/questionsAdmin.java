package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectQuestions;
import exam.model.questionModel;

@WebServlet("/questionsAdmin")
public class questionsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd1;
		HttpSession adminsess1=request.getSession();
		String clss_no=(String) adminsess1.getAttribute("clss_no");
		ArrayList<questionModel> quelist=new ArrayList<questionModel>();
		ArrayList<questionModel> subname=new ArrayList<questionModel>();
		int m11=selectQuestions.getTotalQuestions(Integer.valueOf(clss_no));
		int m21=selectQuestions.getTotalQuestionsExam(Integer.valueOf(clss_no));
		if(m11==m21)
		{
			adminsess1.setAttribute("flag", "true");
		}else
		{
			adminsess1.setAttribute("flag", "false");
		}
		String sub_name=request.getParameter("select");
			if(sub_name!="SELECT")
		{
			quelist=selectQuestions.getQuestionForStud(sub_name, Integer.valueOf(clss_no));
			int n=selectQuestions.getNoOfQuestions(Integer.valueOf(clss_no), sub_name);
			int n1=selectQuestions.getNoOfQuestionsAdded(Integer.valueOf(clss_no), sub_name);
			adminsess1.setAttribute("n", (n-n1));
			request.setAttribute("questions", quelist);
			subname=(ArrayList<questionModel>) selectQuestions.getSubjectName(Integer.valueOf(clss_no));
			request.setAttribute("subname", subname);
			rd1=request.getRequestDispatcher("questionsAdmin.jsp");
			rd1.forward(request, response);
		}else
		if(selectQuestions.getSubjectName(Integer.valueOf(clss_no))!=null)
			{
			subname=(ArrayList<questionModel>) selectQuestions.getSubjectName(Integer.valueOf(clss_no));
			request.setAttribute("subname", subname);
			rd1=request.getRequestDispatcher("questionsAdmin.jsp");
			rd1.forward(request, response);
			}
		
			
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
